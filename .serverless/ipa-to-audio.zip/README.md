# ipa-to-audio
serverless app that will take international phonetic alphabet and return an audio file of AWS Polly pronouncing it
