import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='akaigamedev',
    application_name='ipa-to-audio',
    app_uid='stTgszBrZsV66q6h3Y',
    org_uid='6d89adf7-6e3f-4721-88b5-0fe84b037364',
    deployment_uid='2c0d6218-5966-4d79-a604-597c9409e3a5',
    service_name='ipa-to-audio',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'ipa-to-audio-dev-ipa_to_audio', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.ipa_to_audio')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
